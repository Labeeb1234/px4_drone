***

## Initial Setup
***

- Software Stack
	- OS-Version: Ubuntu-22.04
	- GZ_Version: Gazebo Sim, version 7.9.0 (Gazebo Garden)
	- Ardupilot_SITL Version: 
- Installation of ardupilot_SITL [link_here]()
- Installation of  ardupilot_SITL with Gazebo [link_here](https://ardupilot.org/dev/docs/sitl-with-gazebo.html)
- Ardupilot Toolchain [link_here](https://github.com/ArduPilot/ardupilot)
- **Note to self** : There may be some issues with the python module while launching the sitl using with mavproxy GCS, the sitl may work even without fixing these issues but some GUI features may not work properly is these python dependency issues aren't fixed. For now these this aren't required hopefully (fix later) 

## Drone-Arudpilot_SITL Integration (PART-1)
***

- Install the GZ_Ardupilot plugins for enabling SITL with the gz_sim as an external simulator [docs_here](https://ardupilot.org/dev/docs/sitl-with-gazebo.html#install-the-ardupilot-gazebo-plugin)
- Some initial environment setups to be done given below (either add in bashrc for automated env setup on new terminal launch else keep doing this )
	- ```bash
	  
		export GZ_VERSION=harmonic/garden (my case its: "garden")
		cd ardupilot_gazebo
		mkdir build && cd build
		cmake .. -DCMAKE_BUILD_TYPE=RelWithDebInfo
		make -j4
	  
	  ```

- After the above setup the environment needs to be setup further for GZ resource paths, cmd given below:
	- ```bash
	  export GZ_SIM_SYSTEM_PLUGIN_PATH=$HOME/<your_ws>/src/ardupilot_gazebo/build:$GZ_SIM_SYSTEM_PLUGIN_PATH	  
export GZ_SIM_RESOURCE_PATH=$HOME/<your_ws>/src/ardupilot_gazebo/models:$HOME/gz_ws/src/ardupilot_gazebo/worlds:$GZ_SIM_RESOURCE_PATH
	  ```

- For testing and simulation system checks do the following:
	- ```bash
	gz sim iris_runway.sdf
	  ```
-  For SITL_gz_bridging
	- ```bash
	  sim_vehicle.py -v ArduCopter -f gazebo-iris --model JSON --map --console
	  ```

- Main basic architecture for Ardupilot_SITL and GZ_SIM:
	- 
		Planner / MAVProxy  
		│  
		│ MAVLink  
		▼  
		SITL (ArduPilot)  
		│ ▲  
		│ │ Sensor Data (JSON)  
		│ │  
		▼ │  
		Simulator (Gazebo)  
		│  
		│ Motor Commands   |
		└─────────────
	- ![[ardupilot_SITL_gz_sim_architecture.canvas]]

- Now for adding the custom models of the drone and Gimbal for simulation
	- PKGing Ardupilot_Gazebo src pkg.
	- Put the required models in the main Ardupilot_Gazebo plugin pkg under the **"models"**  directory and create a sample **"test_world.sdf"**  if required to check if the models and gz topics are being published or exposed properly.
	- For adding the Gimbal model. Since the given Gimbal Model is same as the default one in the existing ardupilot_gazebo pkg which is **"gimbal_small_1d"** we can use the same for it or just replace that pkg with the one provided in case of small alterations in the model files.
	- Now to access or bridge this model data to the ardupilot_SITL first in the main drone model SDF we have to add the ardupilot plugins. Replace the velocity gz plugins with the ardupilot motor velocity control plugins.
	- An extra link to simulate the imu for the ardupilot plugin was added to the model.sdf file  
	-  Seems like the crazyflie drone physical params are so far off the default PID params for the motor velocity based control so a proper tuning of those params is required here.